import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class BrailleFileConverter {

    // Mapping von Buchstaben zu Unicode-Braille-Zeichen
    private static final Map<Character, String> brailleMap = new HashMap<>();

    static {
        // Braille-Buchstaben (a-z)
        brailleMap.put('a', "\u2801"); // ⠁
        brailleMap.put('b', "\u2803"); // ⠃
        brailleMap.put('c', "\u2809"); // ⠉
        brailleMap.put('d', "\u2819"); // ⠙
        brailleMap.put('e', "\u2811"); // ⠑
        brailleMap.put('f', "\u280B"); // ⠋
        brailleMap.put('g', "\u281B"); // ⠛
        brailleMap.put('h', "\u2813"); // ⠓
        brailleMap.put('i', "\u280A"); // ⠊
        brailleMap.put('j', "\u281A"); // ⠚
        brailleMap.put('k', "\u2805"); // ⠅
        brailleMap.put('l', "\u2807"); // ⠇
        brailleMap.put('m', "\u280D"); // ⠍
        brailleMap.put('n', "\u281D"); // ⠝
        brailleMap.put('o', "\u2815"); // ⠕
        brailleMap.put('p', "\u280F"); // ⠏
        brailleMap.put('q', "\u281F"); // ⠟
        brailleMap.put('r', "\u2817"); // ⠗
        brailleMap.put('s', "\u280E"); // ⠎
        brailleMap.put('t', "\u281E"); // ⠞
        brailleMap.put('u', "\u2825"); // ⠥
        brailleMap.put('v', "\u2827"); // ⠧
        brailleMap.put('w', "\u283A"); // ⠺
        brailleMap.put('x', "\u282D"); // ⠭
        brailleMap.put('y', "\u283D"); // ⠽
        brailleMap.put('z', "\u2835"); // ⠵

        // Leerzeichen
        brailleMap.put(' ', " ");

    }

    // Funktion, die einen String in Braille konvertiert
    public static String toBraille(String input) {
        StringBuilder brailleOutput = new StringBuilder();

        for (char c : input.toLowerCase().toCharArray()) {
            if (brailleMap.containsKey(c)) {
                brailleOutput.append(brailleMap.get(c));
            } else {
                // Unbekannte Zeichen (z. B. Sonderzeichen) werden übersprungen
                brailleOutput.append("?");
            }
        }

        return brailleOutput.toString();
    }

    // Funktion zum Lesen aus einer Datei, Konvertieren in Braille und Schreiben in eine Datei
    public static void convertFileToBraille(String inputFilePath, String outputFilePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {

            String line;
            while ((line = reader.readLine()) != null) {
                // Konvertiere jede Zeile in Braille
                String brailleLine = toBraille(line);
                // Schreibe die Braille-Zeile in die Ausgabedatei
                writer.write(brailleLine);
                writer.newLine();
            }

            System.out.println("Die Datei wurde erfolgreich in Braille konvertiert und gespeichert: " + outputFilePath);
        } catch (IOException e) {
            System.err.println("Fehler beim Verarbeiten der Datei: " + e.getMessage());
        }
    }

    // Test der Funktion
    public static void main(String[] args) {
        // Pfad zur Eingabedatei und Ausgabedatei
        String inputFilePath = "a.txt"; // Textdatei mit normalem Text
        String outputFilePath = "b.txt"; // Ergebnis in Braille

        // Datei in Braille konvertieren
        convertFileToBraille(inputFilePath, outputFilePath);
    }
}
