import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Einkaufhelfer {
    
	
	private int s1 = 0; //step
	private int c1 = 0; //counter
	private int sk = 0; //skip
	private int st = 0; // 
	private int gp = 0;
	private String test = "";
	private String test2 = "";
	private boolean tb = true;

    public static void main(String[] args) throws IOException {
        Einkaufhelfer e1 = new Einkaufhelfer();
        ArrayList<Verkaeufer> a1 = new ArrayList<>(); //Reine Gesamte Liste als ArrayList
        ArrayList<Verkaeufer> a2 = new ArrayList<>();
        ArrayList<Verkaeufer> a3 = new ArrayList<>(); //K�ufer haben alle diese 2 Karte
        ArrayList<Verkaeufer> a4 = new ArrayList<>();
        ArrayList<ArrayList<Verkaeufer>> a5 = new ArrayList<>(); //Doppelte Eintr�ge werden zusammengef�gt
        ArrayList<ArrayList<Verkaeufer>> a6 = new ArrayList<>(); //Doppelte Eintr�ge werden zusammengef�gt
        ArrayList<ArrayList<Verkaeufer>> a7 = new ArrayList<>(); //Doppelte Eintr�ge werden zusammengef�gt
        ArrayList<ArrayList<Verkaeufer>> a8 = new ArrayList<>(); //Doppelte Eintr�ge werden zusammengef�gt
        ArrayList<Verkaeufer2> a9 = new ArrayList<>();
        
        e1.check1card(a1, a5,a9,"file4.txt");
        
    
  
        

    }
    
    
    public void checkncard( ArrayList<ArrayList<Verkaeufer>> a1,ArrayList<ArrayList<Verkaeufer>> a5,ArrayList<Verkaeufer2> a9 ,ArrayList<String> file) {
    	scantxt3(a1,file);
    	printV(a1);
    	System.out.println(a1.size());
    	
    	createList(a1,a9);
    	printV3(a9);
    	//filter(3, a5);
    	filtIt(a9,2);
    	System.out.println();
    	printV3(a9);
    	
    	sortIt(a9,2);
    	System.out.println();
    	printV3(a9);
    	
    	
    	//sortit(a5, 3);
    	//printV2(a5);
    }
    public void scantxt3(ArrayList<ArrayList<Verkaeufer>> a1,ArrayList<String> file) {
    	
    	for(int i = 0; i<file.size(); i++){
    		scantxt(a1.get(i););
    	}
    	
    }
    
    public void check1card( ArrayList<Verkaeufer> a1,ArrayList<ArrayList<Verkaeufer>> a5,ArrayList<Verkaeufer2> a9 ,String file) {
    	scantxt(a1,file);
    	printV(a1);
    	System.out.println(a1.size());
    	
    	createList(a1,a9);
    	printV3(a9);
    	//filter(3, a5);
    	filtIt(a9,2);
    	System.out.println();
    	printV3(a9);
    	
    	sortIt(a9,2);
    	System.out.println();
    	printV3(a9);
    	
    	
    	//sortit(a5, 3);
    	//printV2(a5);
    }
    

    
    public void showCommon2(ArrayList<ArrayList<Verkaeufer2>>a0,ArrayList<Verkaeufer2> a11,ArrayList<ArrayList<Verkaeufer2>>a12) {
    	
    	for(int i = 0; i<6; i++) {
    		
    	}
    	
    }
    
    public void showCommon(ArrayList<Verkaeufer2> a9,ArrayList<Verkaeufer2> a10,ArrayList<Verkaeufer2> a11) {
    	
    	for(int i = 0; i<a9.size(); i++) {
    		
    	}
    	
    }
    
    public void filtIt(ArrayList<Verkaeufer2> a9, int anzahlKarten) {
        Iterator<Verkaeufer2> iterator = a9.iterator();

        while (iterator.hasNext()) {
            Verkaeufer2 verk = iterator.next();
            if (verk.getPreisliste().size() < anzahlKarten) {
                iterator.remove();  // Sicheres Entfernen w�hrend der Iteration
            }
        }
    }
    
    public void sortIt(ArrayList<Verkaeufer2> a9, int anzahlKarten) {
        a9.sort(Comparator.comparingInt(v -> sumFirstN(v.getPreisliste(), anzahlKarten)));
    }

    // Hilfsmethode zur Berechnung der Summe der ersten N Zahlen
    private int sumFirstN(ArrayList<Double> list, int n) {
        int sum = 0;
        for (int i = 0; i < Math.min(n, list.size()); i++) {
            sum += list.get(i);
        }
        return sum;
    }

    // ArrayList hat mehrere Eintr�ge mit den selben Namen.
    //assemble fusioniert jede 
    public void assemble(ArrayList<ArrayList<Verkaeufer>> a1, ArrayList<Verkaeufer> a2) {
        // Iteriere �ber jeden Verk�ufer in der Liste a2
    	
        for (Verkaeufer verkaeufer : a2) {
            boolean found = false;

            // �berpr�fe, ob es bereits eine Liste f�r den Verk�ufer mit demselben Namen in a1 gibt
            
            for (ArrayList<Verkaeufer> liste : a1) {
                // Wenn ein Verk�ufer mit demselben Namen gefunden wird, f�ge ihn zur bestehenden Liste hinzu
            	test =liste.get(0).getName();
            	test2 = verkaeufer.getName();
            	tb = liste.get(0).getName().equals(verkaeufer.getName());
            	
                if (!liste.isEmpty() && liste.get(0).getName().equals(verkaeufer.getName())) {
                    liste.add(verkaeufer);
                    found = true;
                    break;
                }
            }

            // Falls keine Liste mit demselben Namen existiert, erstelle eine neue und f�ge den Verk�ufer hinzu
            if (!found) {
                ArrayList<Verkaeufer> neueListe = new ArrayList<>();
                neueListe.add(verkaeufer);
                a1.add(neueListe);
            }
        }
    }

    
    public void hightlight(ArrayList<ArrayList<Verkaeufer>> a1,ArrayList<ArrayList<Verkaeufer>> a2) {
    	int anzahl = 0;
    	ArrayList<String> names = new ArrayList<>();
    	
    	for(int i = 0; i<a1.size(); i++){
    		
    		names.add(a1.get(i).get(0).getName());
    	}
    	for(int i = 0; i<a2.size(); i++){
    		names.add(a2.get(i).get(0).getName());
    	}
    	
        for(int i = 0; i<a1.size();i++) {
        	for(int e = 0; e<a1.get(i).size();e++) {
        		anzahl += a1.get(i).get(0).getStueckzahl();
        	}
        	System.out.print(a1.get(i).get(0).getName()+" ");
        	System.out.println(anzahl);
        	anzahl = 0;
        }
    }
    
    public void printV2(ArrayList<ArrayList<Verkaeufer>> a1) {
    	System.out.println(a1.size());
    	
    	for(int i = 0; i<a1.size();i++) {
    		for(int e = 0; e<a1.get(i).size();e++) {
    			System.out.print(a1.get(i).get(e).getName()+" ");
    			System.out.print(a1.get(i).get(e).getStueckzahl()+" ");

    			System.out.print(a1.get(i).get(e).getPreis()+" ");
    			System.out.println();
    			
    			
    		}
    	}
    }
    
    
    public void createList(ArrayList<Verkaeufer> a1, ArrayList<Verkaeufer2> a2) {
        System.out.println(a1.size());

        ArrayList<String> tempNameList = new ArrayList<>();
        ArrayList<ArrayList<Double>> preislisten = new ArrayList<>();

        // 1. Namen sammeln und Preisliste initialisieren
        for (Verkaeufer verk : a1) {
            String name = verk.getName();
            if (!tempNameList.contains(name)) {
                tempNameList.add(name);
                preislisten.add(new ArrayList<>()); // Initialisiere Preisliste
            }
            // 2. F�ge Preis zum entsprechenden Verk�ufer hinzu
            int index = tempNameList.indexOf(name);
            preislisten.get(index).add(verk.getPreis());
        }

        // 3. Erstelle Verkaeufer2-Objekte und f�ge sie zur Liste hinzu
        for (int i = 0; i < tempNameList.size(); i++) {
            a2.add(new Verkaeufer2(tempNameList.get(i), preislisten.get(i)));
        }
    }


    
    public void createList2(ArrayList<ArrayList<Verkaeufer>> a1,ArrayList<Verkaeufer2> a2 ) {
    	System.out.println(a1.size());
    	
    	for(int i = 0; i <a1.size(); i++) {
    		for(int e = 0; e<a2.size(); e++) {
    			if(!(a2.get(e).getName().equals(a1.get(i).get(0).getName()))) {
    				a2.add(new Verkaeufer2(a2.get(e).getName(),new ArrayList<Double>()));
    			}
    			
    			for( int a = 0;a< a2.size(); a++) {
    				for(int u = 0 ; u< a1.get(i).size(); u++) {
            				if(a2.get(a).getName().equals(a1.get(i).get(0).getName())){
            					a2.get(a).getPreisliste().add(a1.get(i).get(0).getPreis());
    					
    				}

    			}
    		}
    	}
    	}

    }
    
    public void printV3(ArrayList<Verkaeufer2> a2) {
        for (Verkaeufer2 v2 : a2) {
            System.out.println("Name: " + v2.getName());
            System.out.println("Preisliste: " + v2.getPreisliste());
            System.out.println(); // Leerzeile f�r bessere Lesbarkeit
        }
    }
    
    //sortiert ArrayList nach besten Preis. Abh�ngig vom Preis und St�ckzahl des H�ndler
    public void sortit(ArrayList<ArrayList<Verkaeufer>> a1,int mind) {
    	//boolean changed = false;
    	double cost = 0;
    	//int count = 0;
    	//TreeMap<Integer, Double> tm = new TreeMap<>();
    	ArrayList<Double> sa = new ArrayList<>();
    	ArrayList<Double> sa2 = new ArrayList<>();
    	
    	for(int i = 0; i<a1.size(); i++) {
    		
    		for(int e = 0; e<a1.get(i).size(); e++) {

    			for(int f = 0 ; f<a1.get(i).get(e).getStueckzahl();f++) {
    				sa.add(a1.get(i).get(e).getPreis());
    			}
    			
    		}
    		for(int g = 0; g<mind;g++) {
    			cost+=sa.get(g);
    		}
    		sa2.add(cost);
    		cost = 0;
    		sa.clear();
    	}
    	selectionSort(sa2,a1);
    	
    	    
    }
    
    public  void selectionSort(ArrayList<Double> list,ArrayList<ArrayList<Verkaeufer>> a1) {
        int n = list.size();
        for (int i = 0; i < n - 1; i++) {
            // Finde das kleinste Element in der unsortierten Liste
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (list.get(j) < list.get(minIndex)) {
                    minIndex = j;
                }
            }
            // Tausche das gefundene Minimum mit dem ersten unsortierten Element
            ArrayList<Verkaeufer> tempa = a1.get(minIndex);
            double temp = list.get(minIndex);
            
            list.set(minIndex, list.get(i));
            list.set(i, temp);
            
            a1.set(minIndex, a1.get(i));
            a1.set(i,tempa);
        }
    }
    
  
    public void filter(int mind, ArrayList<ArrayList<Verkaeufer>> a1) {
        for (int i = a1.size() - 1; i >= 0; i--) {  // R�ckw�rts iterieren, um Probleme mit dem Entfernen zu vermeiden
            int anzahl = 0;  // Setze die St�ckzahl f�r jede Liste zur�ck
            for (int e = 0; e < a1.get(i).size(); e++) {
                // F�ge die St�ckzahl jedes Verk�ufers in der inneren Liste hinzu
                anzahl += a1.get(i).get(e).getStueckzahl();
            }
            
            // Wenn die Summe der St�ckzahlen kleiner als "mind" ist, entferne diese Liste
            if (anzahl < mind) {
                a1.remove(i);
            }
        }
    }
    
    public void printV(ArrayList<Verkaeufer> a1) {
    	System.out.println();
        for (int i = 0; i < a1.size(); i++) {
        	System.out.print(a1.get(i).getName()+", ");
        	System.out.print(a1.get(i).getPreis()+"�, ");
        	System.out.println(a1.get(i).getStueckzahl());
        }
    }
    
    
    public void scantxt(ArrayList<Verkaeufer> a1,String file) {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line = br.readLine();
            while (line != null) {
            	if( st >0) {
            		
            		if (line.equals("")) {
                		gp++;
                    	if(gp>=2) {
                    		break;
                    	}
                	}else {
                		gp =0;
                	}
                		if(sk >1) {
                    		sk--;
                    	} else {
                    		scanline(line, a1);
                    	}
                        line = br.readLine();  // Lese die n�chste Zeile
                        
            	}else {
            		st= 1;
            		line = br.readLine();  // Lese die n�chste Zeile
            	}
            	
            	
            	
            	
            } 

        } catch (IOException e) {
            e.printStackTrace();
        }
        s1 = 0;
        c1 = 0;
        st = 0;
        sk = 0;
        gp = 0;
        //s1,c1,st,sk,gp = 0;
    }
    
    

    public void scanline(String line, ArrayList<Verkaeufer> a1) {
        
        switch (s1) {
            case 0:
                s1++; // Wechsle zum n�chsten Zustand
                break;
                
            case 1:
                if (!line.equals("K")) {
                    s1++; // Wechsle zum n�chsten Zustand
                }
                break;
                
            case 2:
                // F�ge den Verk�ufer mit dem aktuellen Namen hinzu
                a1.add(new Verkaeufer(line, 0, 0));
                s1 = 5;  // Springe zum Zustand, in dem der Preis hinzugef�gt wird
                break;
                
            case 5:
                // �berpr�fe, ob die Zeile einem Euro-Betrag entspricht
                String euroPattern = "\\d{1,3},\\d{2} �";
                Pattern pattern = Pattern.compile(euroPattern);
                Matcher matcher = pattern.matcher(line);
                if (matcher.matches()) {
                    String cleanBetrag = line.replace(" �", "").replace(",", ".");
                    double betrag = Double.parseDouble(cleanBetrag);
                    a1.get(c1).setPreis(betrag);  // Setze den Preis des aktuellen Verk�ufers
                    s1++;  // Wechsle zum Zustand, um die St�ckzahl zu lesen
                }
                break;
                
            case 6:
                // Versuche, die St�ckzahl zu parsen
                int foo;
                try {
                	foo = Integer.parseInt(line);
                    
                } catch (NumberFormatException e) {
                    foo = 0;  // Fallback-Wert bei Fehler
                }
                  // Setze die St�ckzahl des aktuellen Verk�ufers
                
                  // Erh�he den Verk�uferindex
                
                  // Zur�ck zum ersten Zustand, um den n�chsten Verk�ufer zu verarbeiten
                
                if(foo>2) {
                	a1.get(c1).setStueckzahl(foo);
                	s1 = 0;
                	c1++;
                	sk =3;
                } else if(foo==1) {
                	a1.get(c1).setStueckzahl(foo);
                	s1 = 0;
                	c1++;
                }
                
                
            	//c1++;
                break;
            case 7:
            	s1++;
            case 8:
            	s1 = 0;
            	c1++;
        }}
    
    // Diese Methode findet die gemeinsamen Elemente zwischen zwei Listen
    public ArrayList<Verkaeufer> findSame(ArrayList<Verkaeufer> list1, ArrayList<Verkaeufer> list2) {
        // Erstelle eine neue Liste f�r die gemeinsamen Elemente
        ArrayList<Verkaeufer> commonElements = new ArrayList<>(list1);
        // Behalte nur die Elemente, die in beiden Listen enthalten sind
        commonElements.retainAll(list2);
        return commonElements;
    }
    public void findCommon(ArrayList<Verkaeufer> a1, ArrayList<Verkaeufer> a2,ArrayList<Verkaeufer> a3) {

        
        // Vergleiche die Namen der Verk�ufer in den beiden Listen
        for (Verkaeufer v1 : a1) {
            for (Verkaeufer v2 : a2) {
                if (v1.getName().equals(v2.getName())) {
                    a3.add(v1);  // F�ge den Verk�ufer aus der ersten Liste hinzu
                    
                    break;  // Verlasse die innere Schleife, sobald ein passender Name gefunden wurde
                }
            }
        }
    }
    public void findCommon2(ArrayList<ArrayList<Verkaeufer>> a1, ArrayList<ArrayList<Verkaeufer>> a2, ArrayList<ArrayList<Verkaeufer>> a3) {
        
        // Vergleiche die Namen der Verk�ufer in den beiden Listen
        for (int i = 0; i < a1.size(); i++) {
            String nameA1 = a1.get(i).get(0).getName();  // Hole den Namen des Verk�ufers in a1
            
            // �berpr�fe, ob dieser Verk�ufername in a2 existiert
            for (int e = 0; e < a2.size(); e++) {
                String nameA2 = a2.get(e).get(0).getName();  // Hole den Namen des Verk�ufers in a2
                
                if (nameA1.equals(nameA2)) {
                    a3.add(a1.get(i));  // F�ge die gesamte Liste der Verk�ufer in a3 ein
                    break;  // Verlasse die innere Schleife, sobald eine �bereinstimmung gefunden wurde
                }
            }
        }
    }
    public void sortit2( ArrayList<ArrayList<ArrayList<Verkaeufer>>> a1,int mind) {
    	//boolean changed = false;
    	double cost = 0;
    	//int count = 0;
    	//TreeMap<Integer, Double> tm = new TreeMap<>();
    	ArrayList<Double> sa = new ArrayList<>();
    	ArrayList<Double> sa2 = new ArrayList<>();
    	
    	for(int i = 0; i<a1.size(); i++) {
    		
    		for(int e = 0; e<a1.get(i).size(); e++) {

    			for(int f = 0 ; f<a1.get(i).get(e).getStueckzahl();f++) {
    				sa.add(a1.get(i).get(e).getPreis());
    			}
    			
    		}
    		for(int g = 0; g<mind;g++) {
    			cost+=sa.get(g);
    		}
    		sa2.add(cost);
    		cost = 0;
    		sa.clear();
    	}
    	selectionSort(sa2,a1);
    }
    
    public void check2card() {
    e1.scantxt(a1,"file.txt"); //alle K�ufer mit St�ckzahl und Preis in ArrayList a1
        
        e1.scantxt(a2,"file2.txt");
        
        //e1.printV(a1);
        //e1.printV(a2);
        

        //a3
        e1.printV(a1);
        System.out.println();
        e1.printV(a2);
        System.out.println();
        //e1.printV(a3);
        //e1.printV(a4);
        
        // filter(3,a3,a5)
        e1.assemble(a5, a1);
        e1.assemble(a6,a2);
        System.out.println("a5");
        e1.printV2(a5);
        System.out.println("a6");
        e1.printV2(a6);
        System.out.println();
        
        System.out.println();
        e1.filter(2, a5);
        System.out.println();
        e1.filter(2, a6);
        
        e1.findCommon2(a5, a6,a7); //findet alle K�ufer mit Gemeinsmen Karten in a3 und a4
        e1.findCommon2(a6, a5,a8);
        //e1.printV(a4);
        System.out.println("a7");
        System.out.println();
        e1.printV2(a7);
        System.out.println("a8");
        System.out.println();
        e1.printV2(a8);
        

        e1.sortit(a7, 2);
        e1.sortit(a8, 2);
        e1.printV2(a7);

        e1.printV2(a8);
        
        ArrayList<ArrayList<ArrayList<Verkaeufer>>> a9 = new ArrayList<>();
        a9.add(a7); // F�ge die erste Liste hinzu
        a9.add(a8); // F�ge die zweite Liste hinzu
        //e1.hightlight(a5, a6);
        //e1.printV(a3);
        //e1.printV(a4);
        //e1.findSame(a1, a2);
    }
    
    
}


