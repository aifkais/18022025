import java.util.ArrayList;

public class VVkaeufer2 {

	
	private ArrayList <Verkaeufer2> verkaeuferliste;
	
	public Verkaeufer
	
	
	
}
