class Move:

  def __init__(self, name, type, dmg, acc, prio, eftr, efid, efv):
    self.name = name
    self.type = type
    self.damage = dmg
    self.accuracy = acc
    self.priority = prio
    self.effect = eftr
    self.effectid = efid
    self.effectvalue = efv
