class Moveset:

  def __init__(self, moves):
    self.moves = moves
