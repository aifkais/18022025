
public class Main {

	
	public static void main(String[] args) {
		
		Trainer t1 = new Trainer();
		t1.trainergo();
		
	}
	
	
	
}
