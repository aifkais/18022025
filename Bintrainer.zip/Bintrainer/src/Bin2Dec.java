import java.util.Scanner;

public class Bin2Dec implements Aufgabe{
	
	private String alp = "01";
	private String a = "";
	private String erg = "";
	private String rand= "";
	
	@Override
	public void rechnung(Scanner sc) {
		// TODO Auto-generated method stub
		a= "";
		for(int i = 0; i<8; i++) {
			rand = ""+alp.charAt((int) (Math.random()*alp.length()));
			a = a+rand;
		}
		
		int decimal = Integer.parseInt(a, 2);  
	    erg = Integer.toString(decimal);
	    
		System.out.println(a +" bin -> dec");
		sc.nextLine();
		System.out.println(erg);
		
	}

}
