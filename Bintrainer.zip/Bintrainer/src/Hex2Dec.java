import java.util.Scanner;

public class Hex2Dec implements Aufgabe {
	
	private String alp = "0123456789ABCDEF";
	private String a = "";
	private String erg = "";
	private String rand= "";
	
	@Override
	public void rechnung(Scanner sc) {
		// TODO Auto-generated method stub
		a= "";
		for(int i = 0; i<4; i++) {
			rand = ""+alp.charAt((int) (Math.random()*alp.length()));
			a = a+rand;
		}
		int decimal = Integer.parseInt(a, 16);
		erg = Integer.toString(decimal);
		
		System.out.println(a +" hex -> dec");
		sc.nextLine();
		System.out.println(erg);
		
		
	}

}
