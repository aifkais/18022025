import java.util.Scanner;

public interface Aufgabe {

	
	void rechnung(Scanner sc);
	
}
