import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Trainer {

	
	
	
	public void trainergo(){
		

		
		ArrayList<Aufgabe> a1 = new ArrayList<>();
		a1.add(new Bin2Dec());
		a1.add(new Bin2Hex());
		a1.add(new Dec2Bin());
		a1.add(new Dec2Hex());
		a1.add(new Hex2Bin());
		a1.add(new Hex2Dec());

		Scanner scanner = new Scanner(System.in);
		
		
		while(true) {
			Collections.shuffle(a1);
			
			for (int i = 0; i< a1.size(); i++) {
				a1.get(i).rechnung(scanner);
			}
			System.out.println("Done");
			
		}
		
	}
	
	
	
	
}
