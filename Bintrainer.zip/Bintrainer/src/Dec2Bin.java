import java.util.Scanner;

public class Dec2Bin implements Aufgabe{
	
	private String alp = "0123456789";
	private String a = "";
	private String erg = "";
	private String rand= "";
	@Override
	public void rechnung(Scanner sc) {
		// TODO Auto-generated method stub
		a= "";
		for(int i = 0; i<4; i++) {
			rand = ""+alp.charAt((int) (Math.random()*alp.length()));
			a = a+rand;
		}
		int decimal = Integer.parseInt(a);
		erg = Integer.toBinaryString(decimal);
		
		System.out.println(a +" dec -> bin");
		sc.nextLine();
		System.out.println(erg);

		
	}

}
